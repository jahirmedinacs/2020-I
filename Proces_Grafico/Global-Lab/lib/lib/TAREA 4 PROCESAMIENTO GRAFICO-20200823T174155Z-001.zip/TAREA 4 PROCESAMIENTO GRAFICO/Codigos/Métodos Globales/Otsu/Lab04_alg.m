imag = input('Ingrese direccion de la imagen:','s');
tic
otsu(imag);
toc