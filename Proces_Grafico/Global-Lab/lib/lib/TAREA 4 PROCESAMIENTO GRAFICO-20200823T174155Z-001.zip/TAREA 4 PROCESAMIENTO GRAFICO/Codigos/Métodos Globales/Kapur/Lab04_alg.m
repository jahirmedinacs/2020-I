imag = input('Ingrese direccion de la imagen:','s');
tic
umbral = maxentropia(imag);
toc