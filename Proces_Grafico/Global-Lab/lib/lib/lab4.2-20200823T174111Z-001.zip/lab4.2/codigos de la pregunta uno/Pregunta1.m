%Parametros de la imagen
t=512;dir = 5; %Tama�o t*t, Direcci�n del degradado 1-4 int
ideg=1.0; % Intensidad degradado (preferencia 1-3 float)
%Fondo
p=t*ideg/255;
switch dir
  case 1
    for i=1:t
      for j=1:t
        z(i,j)=i/p;
      end
     end
  case 2
    for i=1:t
      for j=1:t
        z(i,j)=255-(i/p);
      end
    end
  case 3
    for i=1:t
      for j=1:t
        z(i,j)=j/p;
      end
    end
  case 4
    for i=1:t
      for j=1:t
        z(i,j)=255-(j/p);
      end
    end
  case 5
    for i=1:t
      for j=1:t
        z(i,j)=(255-(i/p)+j/p)/2;
      end
    end
  otherwise
    for i=1:t
      for j=1:t
        z(i,j)=i/p;
      end
     end
end

m=[ 1,1,1,1;
    1,1,1,1;
    1,0,0,1;
    1,0,0,1;
    1,1,1,0;
    1,1,0,0;
    1,1,0,0;
    1,1,0,1;];%Inicializaci�n
ale = randi([100 250],8,8); %Aleatorios
m=m.';l=3;
B = flip(m);
creeper = [m;B].';
creeper = creeper.*ale;
%ban=mod(t,8);
if mod(t,8)==0
  a=4*(t/8);
else
  a=0;
endif
modu=mod(t,8);
modu=modu+a;
tab=floor(modu/2);
new=round((t-modu)/8);
for i=1:8
  for j=1:8
    for k=1:new;
      for l=1:new;
        z((k+(new*(i-1)))+tab,(l+(new*(j-1)))+tab)=creeper(i,j);
      end
    end
  end
end
imshow(uint8(z));