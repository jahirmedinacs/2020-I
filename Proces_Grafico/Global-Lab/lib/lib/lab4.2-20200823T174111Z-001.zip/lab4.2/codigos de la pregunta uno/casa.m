A=[zeros(256,256)];

%FONDO 
for i=1:256
  for j=1:256
       A(i,j)=i;   
  end
end 
%techo 
for k=0:40
 for i=30+k:130-k
    for j=120-k:140+k 
       A(i,j)=j-k;
    end
  end
end
%FONDO DE CASA
for i=80:200
   for j=80:180
     A(i,j)=j+1-i;
   end
end

%PUERTA
for i=165:200
   for j=120:140
     A(i,j)=3+(i-j);
   end
end

%VEREDA
for k=0:10
 for i=200+k:210+k
   for j=60-k:200+k
     A(i,j)=j-(k*2);
   end
 end
end 

%ventana1
for i=130:150
  
   for j=90:120
     if(j!=100&&i!=140)
      A(i,j)=j+20;
     end 
   end
end

%ventana2
for i=130:150
   for j=140:170
      if(j!=150&&i!=140)
     A(i,j)=j+20;
     end
   end
end

%ventana3
for i=90:110
   for j=140:170
     if(j!=150&&i!=100)
     A(i,j)=j+20;
     end
   end  
end

%ventana4
for i=90:110  
   for j=90:120
       if(j!=100&&i!=100)
     A(i,j)=j+20;
      end
   end
end



%triangulo 
for c=0:20
 for i=120-c:200+c
   for j=220+c:255-c
     A(i,j)=j-8;
    c++;
   end
 end
end

%triangulo 
for c=0:40
 for i=120-c:200+c
   for j=185+c:240-c
     A(i,j)=j-8;
    c++;
   end
 end
end


%triangulo 
for c=0:15
 for i=120-c:170+c
   for j=2+c:30-c
     A(i,j)=j-1;
    c++;
   end
 end
end

%triangulo 
for c=0:40
 for i=120-c:200+c
   for j=20+c:75-c
     A(i,j)=j-1;
    c++;
   end
 end
end
%luna
for k=0:6
 for i=20+k:40-k
    for j=220-k:230+k 
       A(i,j)=220-(k*2);
    end
  end
end


%manija de puerta 
for k=0:2
 for i=181+k:183-k
    for j=133-k:135+k 
       A(i,j)=220-(k*2);
    end
  end
end


        
size(A)
figure;
subplot(1,1,1),imshow(uint8(A));  
