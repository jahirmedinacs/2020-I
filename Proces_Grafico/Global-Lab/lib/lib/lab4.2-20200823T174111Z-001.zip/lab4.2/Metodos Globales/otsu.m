tic;
clc;
clear;
imd = imread('D:\animales\westconcordorthophoto.png ');
[f,c] = size(imd);
hn = histograma(imd);

vp = [];
k = 1;
for i=1:256
   if(hn(i) ~= 0)
       vp(k) = k;
       k = k+1;
   else
       vp(k) = 0;
       k = k+1;
   end
end


max = -1;
umbral = 0;

for t=1:255
   % fprintf('--->t = %d\n', t);
    w1 = 0;
    w2 = 0;
    u1 = 0;
    u2 = 0;
    for i=1:t
        w1 = w1 + hn(i); 
    end 
   % fprintf('w1 = %f\n', w1);
    w2 = 1 - w1; 
  %  fprintf('w2 = %f\n', w2);
    for i=1:t
        if w1~=0
            u1 = u1 + (hn(i)/w1)*vp(i);
        end
    end
  %  fprintf('u1 = %f\n', u1);
    for i=t+1:256
        if w2~=0
            u2 = u2 + (hn(i)/w2)*vp(i); 
        end
    end
  %  fprintf('u2 = %f\n', u2);
    ut = w1*u1 + w2*u2; 
   % fprintf('ut = %f\n', ut);
    oB = w1*(u1 - ut)^2 + w2*(u2 - ut)^2; 
   % fprintf('oB = %f\n\n', oB);
    if(oB > max)
        max = oB;
        umbral = t-1;
    end
end

for i=1:f
    for j=1:c
        if imd(i,j) <= umbral
            imgbi(i, j) = 0;
        else
            imgbi(i, j) = 255;
        end
    end
end

figure
    subplot(1,2,1); imshow(uint8(imd));
    subplot(1,2,2); imshow(uint8(imgbi)); title(umbral)
whos im
toc;
