tic;
%function me = maxentropia()
im = imread('pout.png');
im = im(:,:,1);
imd = double(im);
[f,c] = size(imd);
hn = histograma(imd);


umbral = 0;
max = -1;

for t=1:256
    r1 = 0;
    w1 = 0;
    w2 = 0;
    r2 = 0;
    eb = 0;
    ew = 0;
    for j=1:t
        w1 = w1 + hn(j); 
    end 
    for i=1:t
        if w1~=0 
            r1 = hn(i)/w1; 
        end
        if r1~=0
            ew = ew + r1*log2(r1); 
        end
    end
    w2 = 1 - w1; 
    for i=t+1:256
        if w1~=0 && w2~=0
            r2 = hn(i)/w2; 
        end
        if r2~=0
            eb = eb + r2*log2(r2); 
        end
    end
    at = -ew + -eb;
    if(at>max)
        max = at;
        umbral = t-1;
    end

end



for i=1:f
    for j=1:c
        if imd(i,j) <= umbral
            imgbi(i, j) = 255;
        else
            imgbi(i, j) = 0;
        end
    end
end

imb = uint8(imgbi);
figure
    subplot(1,2,1); imshow(im)
    subplot(1,2,2); imshow(imb); title(umbral)
whos im
toc;