function imgray = rgbtogray()
    img = imread('D:\animales\imagen2.png');
    R = img(:, :, 1);
    G = img(:, :, 2);
    B = img(:, :, 3);
    [M, N, ~] = size(img);
    imgray = zeros(M, N, 'uint8');
    for i=1:M
        for j=1:N
            imgray(i, j) = (R(i, j)*0.2989)+(G(i, j)*0.5870)+(B(i, j)*0.114);
        end
    end
    imwrite(imgray,'imagen2.png');
end
