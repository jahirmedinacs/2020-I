function hn = histograma(imagen)

[f,c] = size(imagen);
 
h = zeros(1, 256);

for i=1:f
    for j=1:c
        k = imagen(i,j);
        h(k+1) = h(k+1)+1;
    end
end

hn = h/(f*c);

for i=1:256
    fprintf('h(%d) = %.2f\n', i, hn(i));
end
